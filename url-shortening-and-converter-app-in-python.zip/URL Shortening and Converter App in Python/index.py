import pyshorteners
from urllib.request import urlopen

def link_shortener(link):
    shortener = pyshorteners.Shortener() 
    short_link = shortener.tinyurl.short(link)  
    
    #Display
    print('\t[+] Real Link: ' + link)
    print('\t[+] Shortened Link: ' + short_link)

def link_opener(link):
    shortened_url = urlopen(link)
    real_link = shortened_url.geturl() 

    # Display
    print('\t[+] Shortened Link: ' + link)
    print('\t[+] Real Link: ' + real_link)




if __name__ == '__main__' :

    while True:
        ret=False

        print("\n\n================== URL Shortener and Converter =================\n")
        
        print("----- Menu -----\n"
                    "1. Shortening link\n"
                    "2. Convert Shorten link to Real Link\n")

        num = input("Enter your choice: ") 
        link = input("Enter the link: ")    

        if (num == '1') :
            link_shortener(link)
        else :
            link_opener(link)  
        
        user_input=input("\n\nTry again? (Yes/No): ")
        print("\n\n")
        
        if user_input.lower()=='no':
            print("Exit program.")
            break
 
        elif user_input.lower()=='yes':
            ret=True
 
        else:
            print("Wrong input.")
            ret=True
 
 
        if ret:
            continue
